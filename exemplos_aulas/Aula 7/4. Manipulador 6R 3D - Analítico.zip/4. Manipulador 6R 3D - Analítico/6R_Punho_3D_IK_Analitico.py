"""
 Autor: Prof. Lucas Vago Santana
 Curso: Robótica Industrial - Engenharia de Controle e Automação
 Instituição: Ifes - campus Linhares
 Revisado em: 22/05/2022
 
 # Modificação dos exemplos para controle direto da IDE Python
 # Utilize o PLAY e o CTRL+C do Spyder IDE para controlar a simulação sem necessidade de clicar nos botões do CoppeliaSim
"""

import vrep
import time
import sys
import numpy as np

vrep.simxFinish(-1) # just in case, close all opened connections

clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5) # Connect to CoppeliaSim

if clientID!=-1:
   print ('Servidor conectado!') 
else:
    print ('Problemas para conectar o servidor!')
    sys.exit()

#Ativa modo síncrono da RemoteAPI
vrep.simxSynchronous(clientID, True) 

#Inicia a simulação
vrep.simxStartSimulation(clientID,vrep.simx_opmode_blocking);

# Juntas do Robô
_, J0Handle = vrep.simxGetObjectHandle(clientID,'J0',vrep.simx_opmode_oneshot_wait)
_, J1Handle = vrep.simxGetObjectHandle(clientID,'J1',vrep.simx_opmode_oneshot_wait)
_, J2Handle = vrep.simxGetObjectHandle(clientID,'J2',vrep.simx_opmode_oneshot_wait)
_, J3Handle = vrep.simxGetObjectHandle(clientID,'J3',vrep.simx_opmode_oneshot_wait)
_, J4Handle = vrep.simxGetObjectHandle(clientID,'J4',vrep.simx_opmode_oneshot_wait)
_, J5Handle = vrep.simxGetObjectHandle(clientID,'J5',vrep.simx_opmode_oneshot_wait)
_, FrameEHandle = vrep.simxGetObjectHandle(clientID,'FrameE',vrep.simx_opmode_oneshot_wait)
# Alvo
_, AlvoHandle = vrep.simxGetObjectHandle(clientID,'Alvo',vrep.simx_opmode_oneshot_wait)

#Função que obtém a pose de um objeto da cena
#Simula algoritmos de localização global [Ex. Visão Computacional]
def Obter_Pose(handle): 
    _, pos = vrep.simxGetObjectPosition(clientID, handle,-1,vrep.simx_opmode_streaming)
    _, ori = vrep.simxGetObjectOrientation(clientID, handle,-1,vrep.simx_opmode_streaming)
  
    x = pos[0]   
    y = pos[1]
    z = pos[2]
    phi = ori[0]
    theta = ori[1]
    psi = ori[2]
    
    return x, y, z, phi, theta, psi

#Função que obtem o ângulo de uma junta
#Simula encoders absolutos nas juntas
def Obter_Angulo_Junta(handle): 
    _, q_medido = vrep.simxGetJointPosition(clientID,handle,vrep.simx_opmode_streaming)
    return q_medido

# Envia referência de ângulo para juntas
def Setar_Juntas_Robo(q0, q1, q2, q3, q4, q5): 
   #Aplica cálculos ao objeto no simulador
   vrep.simxSetJointTargetPosition(clientID, J0Handle, q0, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J1Handle, q1, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J2Handle, q2, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J3Handle, q3, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J4Handle, q4, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J5Handle, q5, vrep.simx_opmode_streaming)

# Retorna matriz de rotação de objetos da simulação
def Obter_R(phi, theta, psi):
  # Fonte: https://www.coppeliarobotics.com/helpFiles/en/eulerAngles.htm
  R = np.array((
                  (                              np.cos(psi)*np.cos(theta),                             -np.cos(theta)*np.sin(psi),           np.sin(theta) ),
                  ( np.cos(phi)*np.sin(psi) + np.cos(psi)*np.sin(phi)*np.sin(theta), np.cos(phi)*np.cos(psi) - np.sin(phi)*np.sin(psi)*np.sin(theta), -np.cos(theta)*np.sin(phi) ),
                  ( np.sin(phi)*np.sin(psi) - np.cos(phi)*np.cos(psi)*np.sin(theta), np.cos(psi)*np.sin(phi) + np.cos(phi)*np.sin(psi)*np.sin(theta),  np.cos(phi)*np.cos(theta) )
              ))
  return R

def Obter_R_3_0(q0, q1, q2):
  R = np.array((
                  (np.sin(q1 + q2)*np.cos(q0), np.sin(q0), np.cos(q0)*np.cos(q1 + q2)),
                  (np.sin(q0)*np.sin(q1 + q2), -np.cos(q0), np.sin(q0)*np.cos(q1 + q2)),
                  (np.cos(q1 + q2), 0, -np.sin(q1 + q2))
              ))
  return R

def Cinematica_Inversa(xd, yd, zd, phid, thetad, psid):
    ######################################
    ## Cinemática Inversa de Orientação ##
    ######################################
    
    #Parâmetros do robô - Cinemática Inversa
    a0 = 0.3
    a1 = 0.5
    a2 = 0.5 + 0.05 #a2 + a3 (muda final do elo para centro do punho)
    a3 = 0.05 #considerado
    a4 = 0.05
    a5 = 0.02
   
    #Inicializa as variáveis localmente na função
    q0 = Obter_Angulo_Junta(J0Handle)
    q1 = Obter_Angulo_Junta(J1Handle)
    q2 = Obter_Angulo_Junta(J2Handle)
    q3 = Obter_Angulo_Junta(J3Handle)
    q4 = Obter_Angulo_Junta(J4Handle)
    q5 = Obter_Angulo_Junta(J5Handle)
    
    r = np.sqrt(xd**2+yd**2+zd**2)
    
    if r >= 0 and r <= a0+a1+a2+a3+a4+a5:
        
        ######################################
        ## Cinemática Inversa de Posição    ##
        ######################################
        d = (a4 + a5)
    
        R_6_0_d = Obter_R(phid, thetad, psid) # No simulador, orientação do alvo    
        
        xp = xd - d * R_6_0_d[0,2] 
        yp = yd - d * R_6_0_d[1,2]  
        zp = zd - d * R_6_0_d[2,2]
        
        r1 = np.sqrt(xp**2+yp**2)
        r2 = zp - a0
        r3 = np.sqrt(r1**2+r2**2)
    
        G = np.arctan2(r2,r1)
        
        B = np.arccos((r3**2+a1**2-a2**2)/(2*r3*a1))
        
        q0 = np.arctan2(yp, xp)
        q1 = np.pi/2 - B - G
        q2 =  np.pi/2 - (np.arccos((a1**2+a2**2-r3**2)/(2*a1*a2)))
        
        ######################################
        ## Cinemática Inversa de Orientação ##
        ######################################
        R_3_0 = Obter_R_3_0(q0, q1, q2)
        
        R_6_3 = np.dot(np.linalg.inv(R_3_0), R_6_0_d)
        
        print(np.array2string(R_6_3, formatter={'float_kind': '{0:.1f}'.format}))
        
        q4 = np.arccos(R_6_3[2,2])
        q3 = np.arctan2(R_6_3[1,2], R_6_3[0,2])
        #q5 = np.arctan2(R_6_3[2,1] , R_6_3[2,0])  
        #q5 = - np.arctan2(R_6_3[2,1] , R_6_3[2,0])  
        q5 = np.pi - np.arctan2(R_6_3[2,1] , R_6_3[2,0])  
        # Ainda não compreendo o motivo da soma de PI em q5
        
        isOK = 1
    else:
        isOK = 0
    
    return q0, q1, q2, q3, q4, q5, isOK

def main():
    #Controle do tempo de simulação
    dt = 0.05
    t = 0
     
    while vrep.simxGetConnectionId(clientID) != -1:
        t0 = time.perf_counter() #Controle de tempo
        t+=dt    
        # Obtém Pose do Alvo
        xd, yd, zd, phid, thetad, psid = Obter_Pose(AlvoHandle)
    
        #Obtém pose da ferramenta
        x, y, z, phi, theta, psi = Obter_Pose(FrameEHandle)
        
        #Aplica cinemática inversa
        q0_r, q1_r, q2_r = 0,0,0
        q3_r, q4_r, q5_r = 0,0,0
        q0_r, q1_r, q2_r, q3_r, q4_r, q5_r, isOK = Cinematica_Inversa(xd, yd, zd, phid, thetad, psid)
        
        # Seta referência das juntas
        Setar_Juntas_Robo(q0_r, q1_r, q2_r, q3_r, q4_r, q5_r)
    
        #Print de dados
        if isOK:
            print("xd: %1.2f      x: %1.2f" % (xd, x))
            print("yd: %1.2f      y: %1.2f" % (yd, y))
            print("zd: %1.2f      z: %1.2f" % (zd, z))
            print("phid: %1.2f    phi: %1.2f" % (phid, phi))
            print("thetad: %1.2f  theta: %1.2f" % (thetad, theta))
            print("psid: %1.2f    psi: %1.2f" % (psid, psi))
        else:
            print("ERRO NA CINEMÁTICA INVERSA!")
        #Disparo do trigger de simulação
        vrep.simxSynchronousTrigger(clientID); # Trigger next simulation step (Blocking function call)
        
        #Aguardando dt
        while(time.perf_counter()-t0 <= dt): _ # Loop de 50ms
try:
    main()
    
except KeyboardInterrupt:
    # stop the simulation:
    vrep.simxStopSimulation(clientID,vrep.simx_opmode_blocking)

    # Now close the connection to CoppeliaSim:
    vrep.simxFinish(clientID)