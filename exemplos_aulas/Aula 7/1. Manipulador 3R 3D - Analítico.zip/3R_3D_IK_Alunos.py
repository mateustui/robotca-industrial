"""
 Autor: Prof. Lucas Vago Santana
 Curso: Robótica Industrial - Engenharia de Controle e Automação
 Instituição: Ifes - campus Linhares
 Revisado em: 22/05/2022
 
 # Modificação dos exemplos para controle direto da IDE Python
 # Utilize o PLAY e o CTRL+C do Spyder IDE para controlar a simulação sem 
   necessidade de clicar nos botões do CoppeliaSim
"""

import vrep
import time
import sys
import numpy as np

vrep.simxFinish(-1) # just in case, close all opened connections

clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5) # Connect to CoppeliaSim

if clientID!=-1:
   print ('Servidor conectado!') 
else:
    print ('Problemas para conectar o servidor!')
    sys.exit()

#Ativa modo síncrono da RemoteAPI
vrep.simxSynchronous(clientID, True) 

#Inicia a simulação
vrep.simxStartSimulation(clientID,vrep.simx_opmode_blocking);

# Juntas do Robô
_, J0Handle = vrep.simxGetObjectHandle(clientID,'J0',vrep.simx_opmode_oneshot_wait)
_, J1Handle = vrep.simxGetObjectHandle(clientID,'J1',vrep.simx_opmode_oneshot_wait)
_, J2Handle = vrep.simxGetObjectHandle(clientID,'J2',vrep.simx_opmode_oneshot_wait)
_, FrameEHandle = vrep.simxGetObjectHandle(clientID,'FrameE',vrep.simx_opmode_oneshot_wait)
# Alvo
_, AlvoHandle = vrep.simxGetObjectHandle(clientID,'Alvo',vrep.simx_opmode_oneshot_wait)


#Função que obtém a pose de um objeto da cena
#Simula algoritmos de localização global [Ex. Visão Computacional]
def Obter_Pose(handle): 
    _, pos = vrep.simxGetObjectPosition(clientID, handle,-1,vrep.simx_opmode_streaming)
    _, ori = vrep.simxGetObjectOrientation(clientID, handle,-1,vrep.simx_opmode_streaming)

    x = pos[0]   
    y = pos[1]
    z = pos[2]
    phi = ori[0]
    theta = ori[1]
    psi = ori[2]
    
    return x, y, z, phi, theta, psi

#Função que obtem o ângulo de uma junta
#Simula encoders absolutos nas juntas
def Obter_Angulo_Junta(handle): 
    _, q_medido = vrep.simxGetJointPosition(clientID,handle,vrep.simx_opmode_streaming)
    return q_medido

# Envia referência de ângulo para juntas
def Setar_Juntas_Robo(q0, q1, q2): 
   #Aplica cálculos ao objeto no simulador
   vrep.simxSetJointTargetPosition(clientID, J0Handle, q0, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J1Handle, q1, vrep.simx_opmode_streaming)
   vrep.simxSetJointTargetPosition(clientID, J2Handle, q2, vrep.simx_opmode_streaming)

#Cinemática inversa
def Cinematica_Inversa(xd, yd, zd):
    #Parâmetros do robô - Cinemática Inversa
    a0 = 0.3
    a1 = 0.5
    a2 = 0.5
    
    #Inicializa as variáveis localmente na função
    q0 = Obter_Angulo_Junta(J0Handle)
    q1 = Obter_Angulo_Junta(J1Handle)
    q2 = Obter_Angulo_Junta(J2Handle)
    
    r1 = np.sqrt(xd**2+yd**2)
    
    if r1 <= (a1 + a2) and (zd <= a0 + a1 + a2): 
        #implementa a cinemática inversa
        isOK = 1
    else:
        print("ERRO NA CINEMÁTICA INVERSA!")
        isOK = 0
    
    return q0, q1, q2, isOK

def main():
    ############################################
    # Variáveis globais de simulação
    ############################################
    
    #Inicialização
    dt = 0.05
    
    #Controle do tempo de simulação
    t = 0
     
    while vrep.simxGetConnectionId(clientID) != -1:
        t0 = time.perf_counter() #Controle de tempo
        t+=dt    
        # Obtém Pose do Alvo
        xd, yd, zd, phid, thetad, psid = Obter_Pose(AlvoHandle)
    
        x, y, z, phi, theta, psi = Obter_Pose(FrameEHandle)
        
        #Aplica cinemática inversa
        
        q0_r, q1_r, q2_r, isOK = Cinematica_Inversa(xd, yd, zd)
        
        # Seta referência das juntas
        Setar_Juntas_Robo(q0_r, q1_r, q2_r)
        
        #Print de dados
        print("xd: %1.2f  yd: %1.2f  zd: %1.2f" % (xd, yd, zd))
        print(" x: %1.2f   y: %1.2f   z: %1.2f" % (x, y, z))
        
        if not(isOK):
            print("ERRO CINEMÁTICA INVERSA!")
        
        #Disparo do trigger de simulação
        vrep.simxSynchronousTrigger(clientID); # Trigger next simulation step (Blocking function call)
        
        #Aguardando dt
        while(time.perf_counter()-t0 <= dt): _ # Loop de 50ms
try:
    main()
    
except KeyboardInterrupt:
    # stop the simulation:
    vrep.simxStopSimulation(clientID,vrep.simx_opmode_blocking)

    # Now close the connection to CoppeliaSim:
    vrep.simxFinish(clientID)